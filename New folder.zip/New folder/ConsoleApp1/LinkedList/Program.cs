﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Problem 2

namespace LinkedList
{
    class Program
    {
        public int Solution(int[] a,int size)
        {
            int temp = 0;
            for(int i=0;i<size;i++)
            {
                if (a[i] > -1)
                    temp++;
                else
                    continue;
                    
            }
            return temp;
        }
        public static void Main(string[] args)
        {
            int[] a = new int[100];
            Console.WriteLine("Enter the size of an array:");
            int size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements");
            for (int i = 1; i <= size; i++)
                a[i] = Convert.ToInt32(Console.ReadLine());
            Program p = new Program();
            int count=p.Solution(a,size);
            Console.WriteLine(count);
            Console.Read();
        }
    }
}
