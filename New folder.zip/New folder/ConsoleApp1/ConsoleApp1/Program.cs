﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Problem 1

namespace ConsoleApp1
{
    public class Program
    {
        int i;
        public bool Singlesort(int[] val)
        {
           
            int temp = 0;
            int swap = 0;
           


                for (i = 0; i < val.Length - 1;)
                {
                    if (val[i] > val[i + 1])
                    {
                        temp = val[i];
                        val[i] = val[i + 1];
                        val[i + 1] = temp;
                        swap++;
                      
                    }
                    i++;
                }

            if (swap > 1)
                return false;
            else
                return true;

        }
        public static void Main(string[] args)
        {
            int[] val=new int[50];
            Console.WriteLine("Enter size of array");
            int size = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < size; i++)
                val[i] = Convert.ToInt32(Console.ReadLine());
            Program p = new Program();
            bool r=p.Singlesort(val);
            if (r == true)
                Console.WriteLine("Success");
            else
                Console.WriteLine("Fail");

            Console.ReadLine();
           
            //for (i = 0; i < val.Length; i++)
            //    Console.WriteLine(val[i]);111111

        }
    }
}
