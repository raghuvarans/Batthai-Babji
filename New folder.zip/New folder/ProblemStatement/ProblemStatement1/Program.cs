﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ProblemStatement1
{
     class Program
    {
        public int solution(int[] A,int size)
        {
            

            int depth = -1;
            int P, Q, R;
            int i = 0, j, k;
            while (i < size - 2)
            {
                P = A[i];

                j = i + 1;
                int p = P;
                while (j < size - 1 && A[j] < p)
                {
                    p = A[j++];
                }
                if (j == size - 1)
                {
                    break;
                }
                if (j > i + 1)
                {
                    Q = A[j - 1];
                }
                else
                {
                    i++;
                    continue;
                }
                k = j;
                int q = Q;
                while (k < size && A[k] > q)
                {
                    q = A[k++];
                }

                if (k > j)
                {
                    R = A[k - 1];
                    depth = Math.Max(depth, Math.Min(P - Q, R - Q));
                    i = k - 1;
                }
                else
                {
                    i = j - 1;
                }
            }

            return Math.Max(depth, -1);
        

    }
        public static void Main(string[] args)
        {
            int[] a = new int[50];
            Console.WriteLine("Enter the size of array:");
            int size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements:");
            for (int i = 0; i < size; i++)
                a[i] = Convert.ToInt32(Console.ReadLine());
            Program p = new Program();
            int result=p.solution(a,size);
            Console.WriteLine("The result is :"+result);
            Console.Read();
        }
    }
}
