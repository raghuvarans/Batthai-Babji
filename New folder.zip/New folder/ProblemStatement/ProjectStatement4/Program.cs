﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectStatement4
{
    class Program
    {
        public int solution(int[] A,int s)
        {
            int majorIndex = 0;
            int count = 0;

            for (int i = 0; i <s; i++)
            {
                if (A[i] != A[majorIndex])
                { 
                    count--;
                    if (count == 0)
                    {
                        majorIndex = i;
                        count = 1;
                    }
                }
                else
                    count++;
            }
            if (count > 0)
            {
                count = 0;
                for (int i = 0; i < s; i++)
                {
                    if (A[i] == A[majorIndex])
                        count++;
                }
                if (count > s / 2)
                    return A[majorIndex];
            }
            return -1;
            
        }
        public static void Main(string[] args)
        {
            int[] a = new int[50];
            int result;
            Console.WriteLine("Enter the size of array");
            int size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements");
            for (int i = 0; i < size; i++)
                a[i] = Convert.ToInt32(Console.ReadLine());
            Program p = new Program();
            result = p.solution(a, size);
            Console.WriteLine(result);
            Console.Read();
        }
    }
}
